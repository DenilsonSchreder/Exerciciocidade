export function MainContainer() {
	return (
		<div id="main" className="flex justify-center bg-verdant-bg">
			<div className="flex flex-col items-center justify-center lg:flex-row">
				<div className="mx-12 mb-8 mt-8 lg:mb-0 lg:mt-0">
					<img
						src="https://seeklogo.com/images/J/joinville-ec-logo-B62D544A8A-seeklogo.com.png"
						alt="PFP"
						className="h-60 w-60 rounded-full bg-verdant-bg-light p-4"
					/>
				</div>
				<div className="mx-12 mb-8 items-center justify-center lg:mx-8 lg:mb-0">
					<div className="text-3xl font-bold text-verdant-fg">
						<span className="text-verdant-blue">Joinville</span>!
					</div>
					<div className="text-base text-verdant-fg-dark">
						Joinville é um município localizado na região norte do estado de Santa Catarina.
						<br />
						<br />
						Sua população, conforme dados do Censo de 2022 do IBGE, era de 616 317 habitantes, sendo a maior cidade do estado,
						<br /> à frente da capital Florianópolis, e é a terceira mais populosa cidade da Região Sul do Brasil atrás apenas de {" "}
						<span className="text-verdant-blue">Porto Alegre</span>,{" "}
						<span className="text-verdant-purple">e Curitiba{" "}
						<br />A cidade possui um elevado índice de desenvolvimento humano (0,809) entre os municípios brasileiros, ocupando a {" "}
						<span className="text-verdant-orange">21ª posição nacional</span>,
						<br />
					</div>
				</div>
			</div>
		</div>
	);
}

export default MainContainer;
